"use strict";


// Select Background.ui
ClickyDrive.background='Assets/Background.png';

// set ui
ClickyDrive.ui='UI.html';

// start the game, this should always be kept last, more or less at least.	
ClickyDrive.game = new Phaser.Game(config);



